package com.mycompany.orangeschool;

import com.mycompany.orangeschool.grafica.Alumnos;
import com.mycompany.orangeschool.grafica.Menu;
import com.mycompany.orangeschool.grafica.InicioSesion;


public class OrangeSchool {

    public static void main(String[] args) {
        
        
        
        
        InicioSesion inicio = new InicioSesion();
        inicio.setVisible(true);
        inicio.setLocationRelativeTo(null);
                
    }
}
